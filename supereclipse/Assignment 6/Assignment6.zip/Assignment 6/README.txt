This is an instruction manual for Sivan Cooperman's recreation of Frogger.

OBJECTIVE: Reach the other side of the street without getting run over by a car! The cars get faster the closer you get to the top! Beware, there's a small chance that a super car will spawn that goes super fast!

CONTROLS: Use arrow keys to move the frog left, right, up, or down. Restart the program in order to play again.