package edu.nyu.cs.sc7443;

import java.lang.Math;

/**
 * The Moped class contains several methods that implement various functions
 * of a moped driving around the city, including the ability to move, check and fill
 * gas, park, and go to a certain named location.
 * @author Sivan Cooperman
 * @version 1.3
 */
public class Moped {
	/**
	 * Constructor that takes a String and creates a moped with that name. Default starting
	 * position for the moped is 10th street and 5th avenue.
	 * @param name The name of the moped.
	 */
	public Moped(String name) {
		this.name = name;
	}
	/**
	 * Constructor that takes a String and creates a moped with that name, and takes a
	 * street and an avenue that the moped is located at. If either the street or the avenue
	 * is set to less than 1, or the street or avenue are set to values that are outside the grid
	 * (i.e. street > 200 or avenue > 10), the default values are used instead.
	 * @param name The name of the moped.
	 * @param street The street the moped is located on. Must be between 1 and 200.
	 * @param ave The avenue the moped is located on. Must be between 1 and 10.
	 */
	public Moped(String name, int street, int ave) {
		this.name = name;
		this.street = (street > 200 || street < 1) ? 10 : street;
		this.ave = (ave > 10 || ave < 1) ? 5 : ave;
	}
	/**
	 * Constructor that takes a String and creates a moped with that name, and takes a
	 * street and an avenue that the moped is located at. If either the street or the avenue
	 * is set to less than 1, or the street or avenue are set to values that are outside the grid
	 * (i.e. street > 200 or avenue > 10), the default values are used instead. Also takes a boolean argument
	 * that describes whether the moped is computer-controlled or not (true being computer-controlled). Only
	 * necessary when creating a computer-controlled moped, as the default state is false.
	 * @param name The name of the moped.
	 * @param street The street the moped is located on. Must be between 1 and 200.
	 * @param ave The avenue the moped is located on. Must be between 1 and 10.
	 * @param drunk True if the moped should be computer-controlled.
	 */
	public Moped(String name, int street, int ave, boolean drunk) {
		this.name = name;
		this.street = street;
		this.ave = ave;
		this.drunk = drunk;
	}
	
	// "go left" and "go right" change depending on your gear; all mopeds have drive and reverse, thus they are static.
	private static final boolean DRIVE = true;
	private static final boolean REVERSE = false;
	
	// how much gas you have in twentieths of a gallon; each block traveled burns 1/20 of a gallon
	private int gas = 20;
	
	private int street = 10; // streets go from 1 to 200, get bigger in the north
	private int ave = 5; // avenues go from 1 to 10, get bigger in the west
	
	// associating the directions with each like this helps to switch directions more easily
	private static final String[] CARDINALS = {"south", "east", "north", "west"}; 
	// default is south
	private int cardinal = 0;
	
	// is the moped parked or not
	private boolean parked = false;
	
	// a non-static variable representing the gears above
	private boolean gear = Moped.DRIVE;
	
	// is this a cpu controlled moped or not
	private boolean drunk = false;
	// to identify multiple mopeds
	private String name;
	
	/**
	 * Sets the parked property to true, and prints the street and avenue on which the moped has
	 * been parked.
	 */
	public void park() {
		System.out.printf("%nThe moped has been parked on the sidewalk at %s Street and %s Avenue.",
				street, ave);
		this.parked = true;
	}
	
	/**
	 * If called by a "drunk" moped, prints that that moped has checked their gas, using their name.
	 * Otherwise prints out the gas property of the moped.
	 */
	public void getGas() {
		if (!drunk) System.out.print("\nYou have " + (this.gas * 100)/20 + "% gas left.");
		else System.out.printf("%n%s checked their gas. ", this.getName());
	}
	
	/**
	 * Checks if the moped is out of gas.
	 * @return True if the moped's gas property is zero, else returns false.
	 */
	public boolean outOfGas() {
		if (this.gas == 0) return true;
		else return false;
	}
	
	/**
	 * Subtracts one unit of gas, and refills a computer-controlled moped's tank
	 * if it falls below a certain threshold (1/4 gallon).
	 */
	public void burnGas() {
		this.gas -= 1;
		// automatically fill up low gas for cpu
		if (this.drunk && this.gas < 5) this.fillTank();
	}
	
	/**
	 * Prints the moped's location, including their name, street, avenue, 
	 * the cardinal direction that they are facing, and their gear (drive or reverse).
	 */
	public void getLocation() {
		System.out.printf("%n%s is currently on %s Street and %s Avenue facing %s, in %s. ",
							this.getName(), this.street, this.ave, CARDINALS[this.cardinal], (this.gear) ? "drive" : "reverse");
	}
	
	/**
	 * Puts the moped's street and avenue into an integer array and returns it.
	 * @return An integer array containing the moped's street and avenue, in that order.
	 */
	public int[] getPos() {
		int[] pos = {this.street, this.ave};
		return pos;
	}
	
	/**
	 * Returns the moped's name.
	 * @return The moped's name property.
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Returns whether the moped is parked or not.
	 * @return The moped's parked property, true or false.
	 */
	public boolean isParked() {
		return this.parked;
	}
	
	/**
	 * Prints that the moped's gas tank has been filled up, and sets the gas property to the maximum.
	 */
	public void fillTank() {
		System.out.printf("%n%s's gas tank has been filled up!", this.getName());
		this.gas = 20;
	}
	
	/**
	 * Sets the moped's gear to drive if given "drive", or reverse otherwise.
	 * @param gear The moped's desired gear (drive or reverse).
	 */
	public void setGear(String gear) {
		this.gear = (gear.equals("drive")) ? Moped.DRIVE : Moped.REVERSE;
	}
	
	/**
	 * Sets the cardinal property to a given integer value corresponding to a cardinal direction (0 is south, 1 is east, 2 is north, 3 is west).
	 * If the value is not between 0 and 3, defaults to 0.
	 * @param cardinal A number between 0 and 3 corresponding to a cardinal direction.
	 */
	public void setDirection(int cardinal) {
		this.cardinal = (cardinal > 3 || cardinal < 0) ? 0 : cardinal;
	}
	
	/**
	 * Sets the cardinal property based on a given relative direction: left, right, back, or straight. If the string is not one
	 * of those directions, nothing happens.
	 * @param direction A string "left", "right", "back", or "straight".
	 */
	public void setDirection(String direction) {
		int newCardinal = this.cardinal;
		
		// make sure we're given a valid direction
		if ("leftrightbackstraight".contains(direction)) {
			// going left/right doesn't change my gear, just my orientation
			// (also, going left in drive and right in reverse are the same in terms of which
			// direction I'm facing, and vice versa)
			if ((direction.equals("left") && gear) || (direction.equals("right") && !gear)) {
				// here the simplicity of the directions array is demonstrated
				// in that I don't have to repeat the operation for both axes
				// conditional operator to loop back around to the beginning
				newCardinal = (this.cardinal == 3) ? 0 : newCardinal + 1;
			} else if ((direction.equals("right") && gear) || (direction.equals("left") && !gear)) {
				newCardinal = (this.cardinal == 0) ? 3 : newCardinal - 1;
			// going forwards/backwards doesn't change my orientation, just my gear
			} else if (direction.equals("back")) this.setGear("reverse");
			else if (direction.equals("straight")) this.setGear("drive");
			
			// now that we've derived the cardinal direction from the relative we can plug it into the other setDirection() function
			this.setDirection(newCardinal);
		}
	}
	
	/**
	 * Moves the moped one block in a given direction and then prints the current location. 
	 * Burns gas and prints advertisements if there are any on the given block.
	 * If the moped runs out of gas, prints so. If a valid direction is not given, prints so.
	 * @param direction A relative direction "left", "right", "back", or "straight" in which the moped should move.
	 */
	public void move(String direction) {
		if ("leftrightbackstraight".contains(direction)) {
			// first discern our cardinal direction based on the relative one
			this.setDirection(direction);
			
			// flag so we can know whether a movement is valid
			boolean canMove = true;
			switch (this.cardinal) {
				// if facing south
				case 0:
					// if we're in drive
					if (gear) {
						// if we can move south, go south
						if (street > 1) street--;
						// otherwise raise a flag
						else canMove = false;
					// if we are in reverse and can move north, do so
					} else if (street < 200) street++;
					// otherwise raise a flag
					else canMove = false;
					break;
				case 1:
					if (gear) {
						if (ave > 1) ave--;
						else canMove = false;
					} else if (ave < 10) ave++;
					else canMove = false;
					break;
				case 2:
					if (gear) {
						if (street < 200) street++;
						else canMove = false;
					} else if (street > 1) street--;
					else canMove = false;
					break;
				case 3:
					if (gear) {
						if (ave < 10) ave++;
						else canMove = false;
					} else if (ave > 1) ave--;
					else canMove = false;
					break;
			}
			// print out our location
			this.getLocation();
			
			// if we've made a legal movement, burn some fuel and print out an ad if we need to
			if (canMove) {
				if (!drunk) {
					CityGrid.printAdvertisement(this);
				}
				this.burnGas();
				
			// otherwise tell them no dice on the movement
			} else System.out.println("Sorry, you can't move in that direction right now.");
			
			// if we're out of gas, say so
			if (this.outOfGas()) {
				System.out.printf("%n%s has run out of gas.", this.getName());
			}
		// if we're not given a valid direction
		} else System.out.println("Please enter a valid direction: left, right, back, or straight");
	}
	
	/**
	 * Can only be called by "drunk" mopeds. Calls a method at random from a predetermined set 
	 * (move, fillTank, getGas, goToPetiteAbeille).
	 */
	public void drunkAction() {
		// can only be performed by CPU-controlled mopeds
		if (this.drunk) {
			// randomly generate a number between 0 and 6
			int action = (int) (Math.random() * 7);
			// obviously the computer doesn't need to use help and shouldn't park, so only 7 actions
			switch (action) {
				case 0:
					this.move("left");
					break;
				case 1:
					this.move("right");
					break;
				case 2:
					this.move("straight");
					break;
				case 3:
					this.move("back");
					break;
				case 4:
					this.fillTank();
					break;
				case 5:
					this.getGas();
					break;
				case 6:
					this.goToPetiteAbeille();
			}
		}
	}
	
	/**
	 * Moves the moped one block at a time to 17th street and 6th avenue, and prints a print
	 * statement after each block and upon arrival noting that the moped has arrived.
	 */
	public void goToPetiteAbeille() {
		System.out.printf("%n%s is going to Petite Abeille!", this.getName());
		// put ourselves into drive
		this.setGear("drive");
		// while we're not there already
		while (!(this.street == 17 && ave == 6)) {
			// if we're north
			if (this.street > 17) {
				if (this.cardinal == 1) move("right");
				else if (this.cardinal == 3) move("left");
				else if (this.cardinal == 0) move("straight");
				else move("back");
			}
			// if we're west
			if (this.ave > 6) {
				if (this.cardinal == 0) move("left");
				else if (this.cardinal == 2) move("right");
				else if (this.cardinal == 1) move("straight");
				else move("back");
			}
			// if we're south
			if (this.street < 17) {
				if (this.cardinal == 1) move("left");
				else if (this.cardinal == 3) move("right");
				else if (this.cardinal == 2) move("straight");
				else move("back");
			}
			// if we're east
			if (this.ave < 6) {
				if (this.cardinal == 0) move("right");
				else if (this.cardinal == 2) move("left");
				else if (this.cardinal == 3) move("straight");
				else move("back");
			}
		}
		// we're here
		System.out.printf("%n%s has arrived! Bon apetit.", this.getName());
	}
	
	/**
	 * To string method for the moped class. includes the drunkenness of the moped,
	 * its location, name, gear, and orientation.
	 */
	public String toString() {
		return String.format("%soped %s at %s Street and %s Avenue facing south in drive.",
							(this.drunk) ? "Drunk m" : "M",
							this.getName(),
							this.street,
							this.ave);
	}
}
