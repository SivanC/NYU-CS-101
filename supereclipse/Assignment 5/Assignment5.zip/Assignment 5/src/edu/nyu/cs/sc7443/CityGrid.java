package edu.nyu.cs.sc7443;

import java.util.Arrays;

/**
 * Manages things that are bigger in scope than
 * the moped class, such as checking for advertisements
 * and checking whether two mopeds have crashed into each other.
 * @author Sivan Cooperman
 * @version 1.0
 */
public class CityGrid {
	
	/* 
	 This method is included in the CityGrid class instead of the Moped class because I feel
	 that crashing into mopeds is not something intrinsic to mopeds but rather to being on the street;
	 a car can crash into a moped, or two cars into each other, but nothing can crash if it's not in the city.
	 If we were to further extend this model you would want the method here for sure. There are also
	 other considerations that might be taken into account such as whether mopeds should even crash into each other
	 if they are headed in different directions, one way streets, etc., which would all be handled here. 
	 */
	/**
	 * Checks if two mopeds have crashed into each other by comparing their street and avenue.
	 * @param m1 The first moped to check.
	 * @param m2 The second moped to check.
	 * @return True if the mopeds crashed, false otherwise.
	 */
	public static boolean crashed(Moped m1, Moped m2) {
		boolean crash = Arrays.equals(m1.getPos(), m2.getPos());
		if (crash) System.out.print("\nOuch! " + m1.getName() + " and " + m2.getName() + " have crashed!");
		return crash;
	}
	
	/**
	 * Gets a moped's location, and prints any relevant advertisements based on that location.
	 * @param m The moped to check.
	 */
	public static void printAdvertisement(Moped m) {
		int[] pos = m.getPos();
		if (Arrays.equals(pos, new int[] {79, 8})) System.out.print("\nWhile you're here, why don't you visit the American Museum of Natural History's T. rex exhibit?");
		else if (Arrays.equals(pos, new int[] {74, 1})) System.out.print("\nDid you know the Memorial Sloan Kettering Cancer Center is the oldest and largest private cancer center in the world?");
		else if (Arrays.equals(pos, new int[] {12, 4})) System.out.print("\nThe Strand bookstore has an amazing rare book collection on the third floor. Check it out!");
		else if (Arrays.equals(pos, new int[] {3, 6})) System.out.print("\nFay Da Bakery has a plethora of delicious pastries!");
	}
}
