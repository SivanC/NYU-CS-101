package edu.nyu.cs.sc7443;

import java.util.Scanner;

/**
 * Program which prompts the user to use
 * various methods of the Moped class to
 * drive around a city grid with two other
 * computer-controlled mopeds.
 * @author Sivan Cooperman
 * @version 1.3
 */
public class TestDrive {
	
	public static void main(String[] args) {
		// getting user input
		Scanner scn = new Scanner(System.in);
		// instantiating the mopeds
		Moped moped = new Moped("Sivan's Moped");
		Moped cpuMoped1 = new Moped("CPU 1", 15, 7, true);
		Moped cpuMoped2 = new Moped("CPU 2", 5, 3, true);
		
		// printing their reprs at the start
		System.out.println(moped.toString());
		System.out.println(cpuMoped1.toString());
		System.out.println(cpuMoped2.toString());
		
		while (!moped.isParked() && !moped.outOfGas() && !(CityGrid.crashed(moped, cpuMoped1) || CityGrid.crashed(moped, cpuMoped2))) {
			
			System.out.println("\n\nWhat would you like to do? Type 'help' for help.\n");
			String task = scn.nextLine().toLowerCase();
			
			switch (task) {
				// turning left
				case "go left":
				case "turn left":
				case "left":
					moped.move("left");
					break;
				// turning right
				case "go right":
				case "turn right":
				case "right":
					moped.move("right");
					break;
				// going straight
				case "straight on":
				case "go straight":
				case "go forwards":
				case "straight":
					moped.move("straight");
					break;
				// going backwards
				case "back up":
				case "go back":
				case "go backwards":
				case "back":
					moped.move("back");
					break;
				// parking
				case "park":
					moped.park();
					break;
				// checking gas
				case "how we doin'?":
				case "check gas":
					moped.getGas();
					break;
				// filling gas
				case "fill 'er up":
				case "fill tank":
					moped.fillTank();
					break;
				// help menu
				case "help":
					System.out.print("\nAvailable commands: go left, go right, straight on, back up, how we doin'?, fill 'er up, park, go to Petite Abeille, help");
					break;
				// going to restaurant
				case "go to petite abeille":
					moped.goToPetiteAbeille();
					break;
				default:
					System.out.print("\nSorry, please try a different command.");
			}
			
			// the cpus do their actions
			cpuMoped1.drunkAction();
			cpuMoped2.drunkAction();
		}
		
		scn.close();
	}

}